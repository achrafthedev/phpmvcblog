<?php

const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'phpmvcblog';

define('APPROOT', dirname(__FILE__, 2));

const URLROOT = 'http://localhost/projetMVC';

const SITENAME = 'PHP MVC Blog';
