<?php
require APPROOT . '/views/includes/head.php';
?>
<div id="section-landing">
    <?php
    require APPROOT . '/views/includes/navigation.php';
    ?>

    <div class="wrapper-landing">
        <h1>PHP MVC W2 PROJECT</h1>
    </div>
</div>